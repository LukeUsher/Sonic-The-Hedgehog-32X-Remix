#include <malloc.h>
#include <sys/types.h>
#include <string.h> 
 
#include "32x.h"
#include "hw_32x.h"

#define SAMPLE_RATE    22050
#define SAMPLE_MIN         2
#define SAMPLE_CENTER    517
#define SAMPLE_MAX      1032 

// PWM Table Entry 
typedef struct
{
	unsigned char* addr;
	long size;
}pwm_entry_t;
 
// PWM Table Structure
typedef struct
{
	int	count;
	pwm_entry_t* samples;
}pwm_table_t;

// Actual PWM Table
pwm_table_t pwmTable;

void PWMTable_AllocateSamples(int count)
{
	pwmTable.samples = (pwm_entry_t*)malloc(sizeof(pwm_entry_t)*count);
	pwmTable.count = 0;
}	

void PWMTable_AddSample(const unsigned char* addr, long size)
{
	pwmTable.samples[pwmTable.count].addr = (unsigned char *)addr;
	pwmTable.samples[pwmTable.count].size = size;
	pwmTable.count++;
}

void PWM_Init() 
{
	// Build PWM Table from ROM Data
	
	// Get Sample count
	uint32_t sampleCount = *((uint32_t*)0x02200000);
	
	// Allocate sample table
	PWMTable_AllocateSamples(sampleCount);
	
	uint32_t* pwmTable_ptr = (uint32_t*)0x02200004;
	
	int i = 0;
	for(i = 0; i < sampleCount*2; i+=2)
	{
		PWMTable_AddSample(pwmTable_ptr[i], pwmTable_ptr[i+1]);
	}
}   

void PWM_PlaySample(unsigned char id)
{
	int i;
	for (i = 0; i < pwmTable.samples[id].size; i++)
	{	
		uint16_t sample = (pwmTable.samples[id].addr[i] << 2) + SAMPLE_CENTER;
		// Wait until not busy
		while (MARS_PWM_MONO & 0x8000)
		{
		}
		// Write the sample to the PWM chip
		MARS_PWM_MONO = sample;	
	
	} 
	// Clear PWM Flag
	(*(volatile unsigned char *)0x20004028) = 0;
}  

void slave_pwm_handler()
{
}
    
void slave(void)  
{   
	PWM_Init();

	// Set Cycle Rate
	if (MARS_VDP_DISPMODE & MARS_NTSC_FORMAT)
	{ 
		MARS_PWM_CYCLE = (((23011361 << 1)/SAMPLE_RATE + 1) >> 1) + 1; 
	}
    else
	{	
        MARS_PWM_CYCLE = (((22801467 << 1)/SAMPLE_RATE + 1) >> 1) + 1; // for PAL clock
	}	

	MARS_PWM_CTRL = 0x305; // TM = 1, RTP, RMD = right, LMD = left
	
	while(1) 
	{   
		unsigned char DAC_SAMPLE = (*(volatile unsigned char *)0x20004028);
		if(DAC_SAMPLE> 0x80)
		{
			PWM_PlaySample(DAC_SAMPLE - 0x81);	
		}
	}
} 
