#include <malloc.h>
#include <sys/types.h>
#include <string.h> 
 
#include "32x.h"
#include "hw_32x.h"


int main(void)
{
    Hw32xInit(MARS_VDP_MODE_256);
    Hw32xSetBGColor(0,0,0,0); // bg = black
	
	int MD_BACKGROUND = 0;	
	while(1)
	{
		// If MD Background colour has changed
		if(MD_BACKGROUND != (*(volatile unsigned short *)0x2000402E))
		{
			// Convert to 32X Colour
			MD_BACKGROUND = (*(volatile unsigned short *)0x2000402E);
			uint8_t red = (MD_BACKGROUND & 0xF) * 2;
			uint8_t green = ((MD_BACKGROUND >> 4) & 0xF) * 2;
			uint8_t blue =  ((MD_BACKGROUND >> 8) & 0xF) * 2;
			// Apply 32X Colour
			Hw32xSetBGColor(0,red, green, blue);
		}
	}
	return 0;
}

